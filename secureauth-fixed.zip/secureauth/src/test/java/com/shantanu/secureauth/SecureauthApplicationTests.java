package com.shantanu.secureauth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecureauthApplicationTests {

	@Test
	void contextLoads() {
	}

}
